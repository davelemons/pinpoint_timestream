## Running Grafana Locally

- [Install Docker](https://www.docker.com/products/docker-desktop)
- Copy Isengard bash/zsh Temporary Credentials into container shell.  This sets temporary creds for Grafana to connect.  Note this is really only good for Demo/POC purposes.  Ideally want to stand this up on Fargate, connect to RDS so configs can be retained.
- Launch Docker `docker run -d -p 3000:3000 --name=grafana -e "GF_INSTALL_PLUGINS=grafana-timestream-datasource" --env ISENGARD_PRODUCTION_ACCOUNT --env AWS_ACCESS_KEY_ID --env AWS_SECRET_ACCESS_KEY --env AWS_SESSION_TOKEN grafana/grafana` 
- Login to Grafana: http://localhost:3000  UN/PW: admin/admin.  It will immediatly ask you to reset password.
- [Configure Timestream Datasource](https://grafana.com/grafana/plugins/grafana-timestream-datasource)
- Auth Provider: Credentials File (will use the env variables passed into docker run command)
- Credentials Profile Name: leave blank
- Default Region: Select your region: US-East-1
- Test your connection and you should be able to see Timestream Databases and Tables.
- Create Dashboard from `dashboard.json`